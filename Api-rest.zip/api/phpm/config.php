<?php

require_once('PHPMailerAutoload.php');


$mail = new PHPMailer;
$mail->IsSMTP();
$mail->Host = 'mail.desarrollos.cl';
$mail->SMTPSecure = 'tls';
$mail->Port = 587;
$mail->Protoco = "mail";
$mail->SMTPAuth = true;
$mail->Username = 'autoresponse@desarrollos.cl';
$mail->Password = 'laCoNtRaSeÑa';
//$mail->SMTPDebug = 2;

// $mail = new PHPMailer();
// $mail->isSMTP();
// $mail->Host = 'smtp.mailtrap.io';
// $mail->SMTPAuth = true;
// $mail->Port = 2525;
// $mail->Username = '1110ef4dfc9e6a';
// $mail->Password = 'e01ff42ea99db6';
