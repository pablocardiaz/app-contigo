<?php 

require '../db/conexion.php';
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTION, PATCH, PUT');
header("Access-Control-Allow-Headers: X-Requested-With, Content-Type, Accept");

$respuesta = array();


if (!isset($respuesta['error'])) {
    try
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {

            $_POST = json_decode(file_get_contents("php://input"), true);

            switch ($_POST['nombreFuncion']) {
                case "Validacion_login":
				    $respuesta["resultado"] = Validacion_login($_POST['rut'],$_POST['contrasenas']);

                   // $respuesta['prueba-Post-test1'] = 'NO SE ENCONTRÓ FUNCIÓN: '. $_POST['nombreFuncion'];
					break;
                default:
                    $respuesta['error-test2'] = 'NO SE ENCONTRÓ FUNCIÓN: '. $_POST['nombreFuncion'];
                    break;
            }


        } else if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            switch ($_GET["nombreFuncion"]) {
                case "Validacion_login":
                    $respuesta["resultado"] = Validacion_login();
		        break; 
                case "obtener_hijos":
                    $respuesta["resultado"] = obtener_hijos($_GET['padre_id']);
		        break;              
								
			  default:
                    $respuesta['error-test3'] = 'NO SE ENCONTRÓ 1: '. $_GET["nombreFuncion"];
                    break;
            }

        } else if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
            $_PUT = json_decode(file_get_contents("php://input"), true);

            // $respuesta = $_PUT['nombreFuncion'] . ' ' . $_PUT['parametros']['usuario'] . ' ' . $_PUT['parametros']['contrasena'];

            switch ($_PUT['nombreFuncion']) {
                default:
                    $respuesta['error-test4'] = 'NO SE ENCONTRÓ FUNCIÓN: '. $_PUT['nombreFuncion'];
                    break;
            }
        }
    } catch (Exception $err) {
        $respuesta['error-test5'] = $err->getMessage();
        $respuesta['codigo'] = $err->getCode();
    }
}

echo json_encode($respuesta);

/* FUNCIÓN VALIDACION LOGIN*/
function Validacion_login($rut,$contrasenas) {
    try 
    {

        $conexion = conexion();
		//$rut= '1034682613';
		//$contrasenas='1234';		/*parametro rut y contrasena estan en bruto*/
        $stmt = $conexion->prepare("CALL SP_VALIDACION_USUARIO(:rut, :Login);");
		$stmt->bindParam(':rut',$rut, PDO::PARAM_STR);
		$stmt->bindParam(':Login',$contrasenas, PDO::PARAM_STR);

        $stmt->execute();
        $resultado = $stmt->fetch();
		
		if($resultado){
		$login = array();
		$login['status']=200;
		$login['padre_id']=$resultado['cedula'];
		return $login;
		}
    } 
    catch (Exception $err) {
        throw $err;
    }
	
	




}

/* FUNCIÓN OBTENER HIJOS*/
function obtener_hijos($padre_id) {
    try 
    {
        $conexion = conexion();
        $query = "SELECT * FROM hijos WHERE padre_id = ".$padre_id;
		$statement = $conexion->prepare($query);
		$statement->execute();
		$resultado = $statement->fetchAll();
		return $resultado;
    } 
    catch (Exception $err) {
        throw $err;
    }
	
	




}
//fin de la clase
?>

