<?php 

require '../db/conexion.php';
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTION, PATCH, PUT');
header("Access-Control-Allow-Headers: X-Requested-With, Content-Type, Accept");
require_once('phpm/config.php');



$respuesta = array();

$emailRemitente = 'contigo@appsalud.com';
$nombreRemitente = 'Contigo Aplicacion Ninos Sanos';



if (!isset($respuesta['error'])) {
    try
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {

            $_POST = json_decode(file_get_contents("php://input"), true);

            switch ($_POST['nombreFuncion']) {
                case "agendar_cita":
				    $respuesta["resultado"] = agendar_cita($_POST['hijo_id'],$_POST['horario_tramo_doctor_id'],$_POST['fecha']);

                   // $respuesta['prueba-Post-test1'] = 'NO SE ENCONTRÓ FUNCIÓN: '. $_POST['nombreFuncion'];
					break;
                case "Validacion_login":
				    $respuesta["resultado"] = Validacion_login($_POST['rut'],$_POST['contrasenas']);

                   // $respuesta['prueba-Post-test1'] = 'NO SE ENCONTRÓ FUNCIÓN: '. $_POST['nombreFuncion'];
					break;
					
					case "Validacion_mail":
                    $respuesta["resultado"] = Validacion_mail($_POST['email']);

                    if (sizeof($respuesta["resultado"]) > 0) {

                        //phpmailer serviria para enviar correo

                    }
                
				 case "Envio_mail_Contrasena":

                    $motivoRemitente = 'Envio de contrasena App Contigo';
					
                    $cuerpoEmail = 
						  '<br />
						  Recibimos la siguiente solicitud de envio de contrasena <br />
						  <br />
						  <br />
						  '; 
										
                    $emailRequest = Validacion_mail($_POST['email']);
                    if ($emailRequest) {
                        $emailReceptor = $_POST['email'];
                        $nombreReceptor = $_POST['email'];
						$mail->MsgHTML($mensaje);
                        $mail->SetFrom($emailRemitente, $nombreRemitente);
                        $mail->Subject = $motivoRemitente;

                        $mail->AddAddress($emailReceptor, $nombreReceptor);
                        $mail->isHTML(true);
                        $cuerpoEmail = $cuerpoEmail . ' Su clave de la aplicacion Contigo es : ' . $emailRequest[7].'<br />'.'<br />'.'<br />Muchas gracias por preferirnos <br />'.'<br />'.'Equipo Contigo';
                        $mail->Body = $cuerpoEmail;
                        if (!$mail->Send()) {
                            $respuesta["resultado"] = "Mailer Error: " . $mail->ErrorInfo;
                        } else {
                            $respuesta["resultado"] = "Contrasena enviada";
                        }
                    }
                    break;
				
				
				
                default:
                    $respuesta['error-test2'] = 'NO SE ENCONTRÓ FUNCIÓN: '. $_POST['nombreFuncion'];
                    break;
            }


        } else if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            switch ($_GET["nombreFuncion"]) {

			case "Validacion_login":
                    $respuesta["resultado"] = Validacion_login($_GET['padre_id']);
		        break; 
                
				case "obtener_hijos":
                    $respuesta["resultado"] = obtener_hijos($_GET['padre_id']);
		        break; 
				
				case "obtener_tipo_cita":
                    $respuesta["resultado"] = GET_TIPO_CITA();
		        break; 
				
				case "obtener_doctor_tipo_cita":
                    $respuesta["resultado"] = GET_DOCTOR_TIPO_CITA($_GET['tipo_cita']);
		        break; 
				
				case "obtener_doctor_tramo":
                    $respuesta["resultado"] = GET_DOCTOR_TRAMOS($_GET['doctor_id'], $_GET['dia']);
		        break; 
				
				case "obtener_doctor_fecha_tramo":
                    $respuesta["resultado"] = GET_DOCTOR_TRAMOS_FECHA( $_GET['fecha']);
		        break; 
				
				case "datos_hijos":
				    $respuesta["resultado"] = datos_hijos($_GET['rut_hijo1']);
				break;						
				
				
				case "OBTENER_DATOS_PADRES":
					$respuesta["resultado"] = OBTENER_DATOS_PADRES($_GET['rut_padre']);
				break;

				
				case "AgendaMedicaFiltro":
				$respuesta["resultado"] = AgendaMedicaFiltro($_GET['especialidad'],$_GET[ 'medico'], $_GET['hijo'],$_GET['padre']);
				break;

				case "ObtenerFichaMedicaHijo":
					$respuesta["resultado"] = ObtenerFichaMedicaHijo($_GET['rut_hijo']);
				break;
				
				
				
			  default:
                    $respuesta['error-test3'] = 'NO SE ENCONTRÓ 1: '. $_GET["nombreFuncion"];
                    break;
            }

        } else if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
            $_PUT = json_decode(file_get_contents("php://input"), true);

            // $respuesta = $_PUT['nombreFuncion'] . ' ' . $_PUT['parametros']['usuario'] . ' ' . $_PUT['parametros']['contrasena'];

            switch ($_PUT['nombreFuncion']) {
                case "ModificarContrasena":
                    $respuesta["resultado"] = ModificarContrasena($_PUT['rut'],$_PUT['contrasenas'],$_PUT['nuevaContrasenas']);

                    break;
                case "ModificarCorreo":
                    $respuesta["resultado"] = ModificarCorreo($_PUT['email'],$_PUT['nuevoEmail']);

                    break;
                case "ModificarCelular":
                    $respuesta["resultado"] = ModificarCelular($_PUT['celular'],$_PUT['nuevoCelular']);

                    break;
            
                    default:
                    $respuesta['error-test4'] = 'NO SE ENCONTRÓ FUNCIÓN: '. $_PUT['nombreFuncion'];
                    break;
            }
        }
    } catch (Exception $err) {
        $respuesta['error-test5'] = $err->getMessage();
        $respuesta['codigo'] = $err->getCode();
    }
}

echo json_encode($respuesta);

/* FUNCIÓN VALIDACION LOGIN*/
function Validacion_login($rut,$contrasenas) {
    try 
    {
        $conexion = conexion();
		//$rut= '1034682613';
		//$contrasenas='1234';		/*parametro rut y contrasena estan en bruto*/
        $stmt = $conexion->prepare("CALL SP_VALIDACION_USUARIO(:rut, :Login);");
		$stmt->bindParam(':rut',$rut, PDO::PARAM_STR);
		$stmt->bindParam(':Login',$contrasenas, PDO::PARAM_STR);

        $stmt->execute();
        $resultado = $stmt->fetch();
		
		if($resultado){
		$login = array();
		$login['status']=200;
		$login['padre_id']=$resultado['cedula'];
		return $login;
		}
    } 
    catch (Exception $err) {
        throw $err;
    }	
}

/* FUNCIÓN RECUPERAR CONTRASEÑA POR EMAIL*/
function Validacion_mail($correo)
{
    try {
        $conexion = conexion();
        $query = "SELECT * FROM registro_tutor WHERE correo = '" . $correo . "'";
        $statement = $conexion->prepare($query);
        $statement->execute();
        $resultado = $statement->fetch();
        if (!$resultado) {
            return false;
        }
        return $resultado;
    } catch (Exception $err) {
        throw $err;
    }
}



/* FUNCIÓN OBTENER HIJOS*/
function obtener_hijos($padre_id) {
    try 
    {
        $conexion = conexion();
        $query = "SELECT * FROM hijos WHERE padre_id = ".$padre_id;
		$statement = $conexion->prepare($query);
		$statement->execute();
		$resultado = $statement->fetchAll();
		return $resultado;
    } 
    catch (Exception $err) {
        throw $err;
    }
}

/* FUNCION CAMBIAR CONTRASEÑA */

function ModificarContrasena($rut, $contrasenas, $nuevaContrasenas) {
    try 
    {
        $conexion = conexion();
        $statement = $conexion->prepare("CALL SP_MODIFICAR_CONTRASENA(:rut, :contrasenas, :nuevaContrasenas);");
        $statement->bindParam(':rut',$rut, PDO::PARAM_STR);
        $statement->bindParam(':contrasenas',$contrasenas, PDO::PARAM_STR);
        $statement->bindParam(':nuevaContrasenas',$nuevaContrasenas, PDO::PARAM_STR);

        $statement->execute();
        $resultado = $statement->fetchAll();
        if($resultado){
            return 'CAMBIO_CONTRASEÑA_OK';
        }
    } 
    catch (Exception $err) {
        throw $err;
    }

}

/* FUNCION CAMBIAR CORREO */
	
function ModificarCorreo($email, $nuevoEmail) {
    try 
    {
        $conexion = conexion();
        $statement = $conexion->prepare("CALL SP_MODIFICAR_CORREO(:email, :nuevoEmail);");
        $statement->bindParam(':email',$email, PDO::PARAM_STR);
        $statement->bindParam(':nuevoEmail',$nuevoEmail, PDO::PARAM_STR);

        $statement->execute();
        $resultado = $statement->fetchAll();
        if($resultado){
            return 'CAMBIO_CORREO_OK';
        }

    } 
    catch (Exception $err) {
        throw $err;
    }	
}

/* FUNCION CAMBIAR CELULAR */
	
function ModificarCelular($celular, $nuevoCelular) {
    try 
    {
        $conexion = conexion();
        $statement = $conexion->prepare("CALL SP_MODIFICAR_CELULAR(:celular, :nuevoCelular);");
        $statement->bindParam(':celular',$celular, PDO::PARAM_STR);
        $statement->bindParam(':nuevoCelular',$nuevoCelular, PDO::PARAM_STR);

        $statement->execute();
        $resultado = $statement->fetchAll();
        if($resultado){
            return 'CAMBIO_CELULAR_OK';
        }

    } 
    catch (Exception $err) {
        throw $err;
    }	

}


	
/*FUNCIÓN DATOS HIJOS*/

function datos_hijos($rut_hijo) {
    try 
    {

        $conexion = conexion();
		$statement = $conexion->prepare("CALL SP_DATOS_HIJOS(:rut_hijo);");
		$statement->bindParam(':rut_hijo',$rut_hijo, PDO::PARAM_STR);
		$statement->execute();
		$resultado = $statement->fetchAll();
		return $resultado;
	}
    catch (Exception $err) {
        throw $err;
    }
}


/*FUNCION DATOS PADRES OBTENER*/

function OBTENER_DATOS_PADRES($rut_padre) {
    try 
    {

        $conexion = conexion();
		$statement = $conexion->prepare("CALL SP_OBTENER_DATOS_PADRES(:rut);");
		$statement->bindParam(':rut',$rut_padre, PDO::PARAM_STR);
		$statement->execute();
		$resultado = $statement->fetchAll();
		return $resultado;
	}
    catch (Exception $err) {
        throw $err;
    }
}


/*FUNCION GET_TIPO_CITA */

function GET_TIPO_CITA() 
{
    try 
    {

        $conexion = conexion();
		
        $query = "SELECT * FROM tipo_cita ";
		$statement = $conexion->prepare($query);
		$statement->execute();
		$resultado = $statement->fetchAll();
		return $resultado;
	}
    catch (Exception $err) {
        throw $err;
    }
}

/*FUNCION GET_DOCTOR_TIPO_CITA */

function GET_DOCTOR_TIPO_CITA($tipo_cita) 
{
    try 
    {

        $conexion = conexion();
        $query = "SELECT registro_doctores.nombre, registro_doctores.apellido, registro_doctores.doctor_id FROM registro_doctores, tipo_cita WHERE registro_doctores.tipo_cita_id = tipo_cita.id AND tipo_cita.id = ". $tipo_cita;
		$statement = $conexion->prepare($query);
		$statement->execute();
		$resultado = $statement->fetchAll();
		return $resultado;
	}
    catch (Exception $err) {
        throw $err;
    }
}

/*FUNCION GET_DOCTOR_TRAMOS */

function GET_DOCTOR_TRAMOS($doctor_id, $dia) 
{
    try 
    {

        $conexion = conexion();
        $query = "SELECT * FROM horario_doctor, horario_tramo_doctor WHERE horario_doctor.doctor_id = ". $doctor_id .
		" AND horario_doctor.dia = " . $dia . " AND horario_doctor.horario_doctor_id = horario_tramo_doctor.horario_doctor_id";
		$statement = $conexion->prepare($query);
		$statement->execute();
		$resultado = $statement->fetchAll();
		return $resultado;
	}
    catch (Exception $err) {
        throw $err;
    }
}

/*FUNCION GET_DOCTOR_TRAMOS */

function GET_DOCTOR_TRAMOS_FECHA($fecha) 
{
    try 
    {
        $conexion = conexion();
        $query = "SELECT * FROM horario_paciente, horario_tramo_doctor WHERE  horario_paciente.fecha = '" . $fecha . 
		"' AND horario_tramo_doctor.horario_tramo_doctor_id = horario_paciente.horario_tramo_doctor_id";
		$statement = $conexion->prepare($query);
		$statement->execute();
		$resultado = $statement->fetchAll();
		return $resultado;
	}
    catch (Exception $err) {
        throw $err;
    }
}


/*FICHA MEDICA HIJO*/
function ObtenerFichaMedicaHijo($rut_hijo) {
    try 
    {

        $conexion = conexion();
		$statement = $conexion->prepare("CALL SP_OBTENER_FICHA_MEDICA_HIJO(:rut_hijo);");
		$statement->bindParam(':rut_hijo',$rut_hijo, PDO::PARAM_STR);
		$statement->execute();
		$resultado = $statement->fetchAll();
		return $resultado;
	}
    catch (Exception $err) {
        throw $err;
    }
}

/*AGENDAR CITA PACIENTE*/
function agendar_cita($hijo_id, $horario_tramo_doctor_id, $fecha) {
    try {
        $conexion = conexion();
		//$query="INSERT INTO horario_paciente (hijo_id, horario_tramo_doctor_id, fecha) VALUES (202202548, 1, '2022-07-12')";
        $query = "INSERT INTO horario_paciente (hijo_id, horario_tramo_doctor_id, fecha) VALUES ('".$hijo_id."', ".$horario_tramo_doctor_id.", '".$fecha."')";
        $statement = $conexion->prepare($query);
        $statement->execute();
        $statement->fetchAll();
		
        return $resultado;
    } catch (Exception $err) {
        throw $err;
    }
}


/*GUARDAR TRAMO HORARIO DOCTOR*//*
function GuardarTramoHorarioDoctor($body) {
    try 
    {
    try {
        $conexion = conexion();
		
		$inicio="0800";
		$fin="1700";
		
		$arr_inicio = str_split($inicio, 2); // => ["08", "00"]
		$hora_inicio = $arr_inicio[0];
		$minuto_inicio = $arr_inicio[1];
		
		$arr_fin = str_split($fin, 2); // => ["17", "00"]
		$hora_fin = $arr_fin[0];
		$minuto_fin = $arr_fin[1];
		
		$respuesta = array();
		
		
        $query = "INSERT INTO `horario_tramo_doctor` (`horario_tramo_doctor`, `hora_inicio`, `hora_fin`, `horario_doctor_id`) VALUES (NULL, '800', '830', '1'), (NULL, '830', '900', '1')";
        $statement = $conexion->prepare($query);
        $statement->execute();
        $resultado = $statement->fetch();
        if (!$resultado) {
            return false;
        }
        return $resultado;
    } catch (Exception $err) {
        throw $err;
    }
}*/


//fin de la clase
?>

