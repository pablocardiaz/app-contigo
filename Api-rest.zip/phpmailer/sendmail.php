<?php
	require_once('phpm/config.php'); 
		
	$emailRemitente = '';
	$nombreRemitente = '';
	$motivoRemitente = '';
	$cuerpoEmail = '';
	
	
	$emailReceptor = '';
	$nombreReceptor = ''; 
	
	
	

	$mail->SetFrom($emailRemitente, $nombreRemitente); 
	$mail->Subject = $motivoRemitente; 
	
	
	
	$mail->AddAddress($emailReceptor, $nombreReceptor);  

	$mail->isHTML(true); 
	
	$mail->Body = $cuerpoEmail; 
	
	if(!$mail->Send()) { 
		
	}else{
		
	}		


?>