<?php

// SERVER
define('HOST', 'localhost');
define('DB', 'desacl_app-contigo');
define('USER', 'desacl_admapp-contigo');
define('PASS', 'q*]9oM7JqyxS');

//LOCALHOST

/*define('HOST', 'localhost');
define('DB', 'desacl_app-contigo');
define('USER', 'root');
define('PASS', '');*/


function conexion()
{
    try {
        $conexion = new PDO("mysql:host=" . HOST . ";dbname=" . DB, USER, PASS);
        $conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $conexion->exec("SET NAMES 'utf8';");
        return $conexion;
    } catch (PDOException $e) {
        throw $e;
    }
}
