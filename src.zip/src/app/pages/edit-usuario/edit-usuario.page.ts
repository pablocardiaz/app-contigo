import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-usuario',
  templateUrl: './edit-usuario.page.html',
  styleUrls: ['./edit-usuario.page.scss'],
})
export class EditUsuarioPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
