import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/services/api.service';
import { AlertController, ToastController } from '@ionic/angular';
import { Router } from '@angular/router';


@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {

  modeloUsuario: string= '';
  modeloContrasena: string='';

  constructor(private alertController: AlertController,
    private api: ApiService,
    private toastController: ToastController,
    private router: Router) { }

  ngOnInit() {
  }
  async mostrarRespuesta(mensaje) {
    const toast = await this.toastController.create({
      message: mensaje,
      duration: 3000
    });
    toast.present();
  }
  /* aca necesito que me enseñe el paso a paso y como entenderlo para poder replicarlo se que va esto hace la validacion del login*/
  login() {
    this.api.login(this.modeloUsuario, this.modeloContrasena).subscribe(data => {
      if (data['result'] === 'LOGIN OK') {
        this.router.navigate(['home'], { replaceUrl: true });
        
      } else {
        this.mostrarRespuesta("Credenciales incorrectas");
      }
    })
  }

  navegar() {
    this.router.navigate(['contrasena']);
  }

}
